<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Base\\App\\Providers\\BaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Base\\App\\Providers\\BaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);