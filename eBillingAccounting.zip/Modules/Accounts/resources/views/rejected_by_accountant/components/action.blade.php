
<div class="btn-group" role="group" aria-label="Basic example">
    <button type="button" class="btn btn-sm btn-info detail_info" data-route="{{ route('voucher.show',encrypt($row->id)) }}"><i class="fa fa-eye"></i>
    </button>
</div>