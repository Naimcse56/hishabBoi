<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Accounts\\App\\Providers\\AccountsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Accounts\\App\\Providers\\AccountsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);