<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Portfolio\\App\\Providers\\PortfolioServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Portfolio\\App\\Providers\\PortfolioServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);