<?php

return [
    App\Providers\AppServiceProvider::class,
    Laravolt\Avatar\ServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class,

];
