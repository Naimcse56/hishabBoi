<?php

return [
    'name' => 'Accounts',
];
