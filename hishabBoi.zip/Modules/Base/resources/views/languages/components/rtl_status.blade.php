@if($row->rtl)
    <span class="badge bg-success">Yes</span>
@else
    <span class="badge bg-danger">No</span>
@endif